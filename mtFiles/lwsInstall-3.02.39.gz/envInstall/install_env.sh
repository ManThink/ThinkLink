#!/bin/sh
echo "install docker"
apt install docker.io -y
echo "install redis database"
apt-get install redis
cp ./redis/* /etc/redis/
systemctl restart redis
echo "install mosquitto tools"
apt-get install mosquitto -y
cp ./mosquitto/*        /etc/mosquitto/
mosquitto_passwd  /etc/mosquitto/pwfile tkbroker
#tkbroker!0901
systemctl restart mosquitto
mkdir -p /var/lib/postgresql/sql /var/lib/postgresql/data
docker run -it --restart=always -d --net=host --name postgres -e POSTGRES_USER=postgres -e POSTGRES_PASSWORD='tkpg!0902' -v /var/lib/postgresql/data:/var/lib/postgresql/data postgres:12.6
#apt-get install postgresql
#cp ./postgresql/* /etc/postgresql/14/main/
# 
#\password postgres
#tkpg!0902@postgres'
#\q
# postgresql.conf 修改 listen_addresses = '*'
# pg_hba.conf 中，增加以下选项
# TYPE  DATABASE        USER            ADDRESS                 METHOD
# host    all             all             0.0.0.0/0               md5
# systemctl restart postgresql
#######################################################################################################################
    #配置文件路径: /etc/postgresql-common/createcluster.conf
    #systemd的服务软连接: /etc/systemd/system/multi-user.target.wants/postgresql.service → /lib/systemd/system/postgresql.service
    #数据目录: /var/lib/postgresql/12/main
    #日志文件: /var/log/postgresql/postgresql-12-main.log
    #特殊的数据库用户: postgres
    #https://zhuanlan.zhihu.com/p/467644334

