# thinkOne3.0
#### 介绍
使用golang 写的第3代thinkOne
#### 软件架构
软件架构说明
#### 安装教程
1. emqx 安装脚本
docker run -it --restart=always -d --net=host --name emqx emqx/emqx:4.4.0
sleep 15
docker exec -it  emqx /bin/sh -c "sed -ie 's/allow_anonymous = true/allow_anonymous = false/g' /opt/emqx/etc/emqx.conf; emqx restart"
sleep 15
docker exec -it  emqx /bin/sh -c "echo 'auth.user.1.username = tkbroker' >> /opt/emqx/etc/plugins/emqx_auth_mnesia.conf"
docker exec -it  emqx /bin/sh -c "echo 'auth.user.1.password = tkbroker!0901' >> /opt/emqx/etc/plugins/emqx_auth_mnesia.conf"
sleep 5
docker exec -it  emqx /bin/sh -c "emqx_ctl plugins load emqx_auth_mnesia"
2. postgres
sudo mkdir -p /var/lib/postgresql/sql /var/lib/postgresql/data
docker run -it --restart=always -d --net=host --name postgres -e POSTGRES_USER=postgres -e POSTGRES_PASSWORD='tkpg!0902' -v /var/lib/postgresql/data:/var/lib/postgresql/data postgres:12.6
#### 使用说明
1. 启动 macos上的redis服务器 ： 
/Volumes/development/myapp/redis-stack-server-7.0.6-RC5.catalina.x86_64/bin/redis-server &
2. 安装路径放在 /usr/local/mt/lws/lws-thinkOne/
3. 执行文件名称 lws-thinkOne ,建议使用 systemd 进行管理
4. -test=true 会进入测试模式
5. 增加一列的 sql 语句 ALTER TABLE mt_sdev_pf_macs ADD COLUMN note TEXT
6. 使用gwm , gwm -pg sql -query "ALTER TABLE mt_sdev_pf_macs ADD COLUMN note TEXT" -db tk015101 -pswd mingz@2021
7. "postgres://postgres:tkpg!0902@iotcn03.manthink.cn:2432/tk015101_bk?sslmode=disable"
### 安装
## 1. 
解压安装包 tar -xvf lws-install-3.02.13.gz
sudo ./install_lws.sh -f lws-conf.json
提前准备 配置文件 lws-conf.json
{
"netEui": "011201",
"redispswd": "tkredis!0903",
"ns": {
"broker": "localhost:1883",
"username": "tkbroker",
"password": "tkbroker!0901"
},
"as": {
"broker": "localhost:1883",
"username": "tkbroker",
"password": "tkbroker!0901"
},
"dms": {
"broker": "localhost:1883",
"username": "tkbroker",
"password": "tkbroker!0901"
},
"postgre": {
"server": "localhost:5432",
"user": "postgres",
"pswd": "tkpg!0902"
},
"postgrebk": {
"server": "localhost:5432",
"user": "postgres",
"pswd": "tkpg!0902"
}
}
#### 参与贡献
#### changelist
***********************************************
3.02.08 - 2023.06.16
first commit
***********************************************
3.02.09 - 2023.06.20
1. 修复了thinkOne的几个bug
***********************************************
**3.02.11  2023.06.21-**
1. 更改了 thinkOne的默认配置，如果netEui配置为 gweui，则从网关的eui配置为 thinkOne eui
2. 增加 license 功能 【待修改】
3. 增加 asbrg下行禁止配置 【待修改】
4. 将thinkOne的配置参数管理放在mtns中，方便其他应用调用和管理
5. 修改了 gw devlist中重复增加的bug
6. 增加了 对下行数据保存到redis的保护。只要有下行数据，就会将下行数据写入到redis中
7. 下行数据增加dataClear功能, 下发数据时， type=dataClear 即可清除原下行数据，如果payload不为""",
    则将新的下行数据增加到下行队列，如果payload位空字符串，则不增加新的下行数据。
8. 增加了micErr的状态提示在 devPfApp的数据项中
9. 增加了因上行帧号增加导致的micerr的自动校正问题
10. 增加了memRefresh 的mqtt功能，当mode=memRefresh 时，可以同步redis中的数据到内存中
11. 增加了通过写入redis内容实现 mqtt 功能 ，可以想 dbDev （1）中的key=dev:action:checkInfo或者devGw（3）
中中的key=gw:action:checkInfo 写入 mqtt的指令内容。 默认 5秒钟检查一次。如果发现有可执行内容，则执行相关操作，bing从redis中删除该信息。
***********************************************
**3.02.13  2023.08.05
1. 增加geo相关功能，通过mqtt指令可以修改设备/网关的地理位置。 type改为 "tkFixed"为固定位置
   其他模式下，将由thinkOne自动计算位置
2. 通过发送geo2redis 将位置信息更新到redis数据库
***********************************************
3.02.14 **3.02.14  2023.08.05 -2023.08.26
1. 增加手动备份的mqtt指令
2. 增加下行confirm包以及确认机制
3. 生成指令增加标签和condition
4. thinkOne兼容 dtuIP的协议格式
5. thinkOne 支持对confirm包的反馈支持
6. thinkOne的 ack分为 ackSeq 和ackSuc/ackFail 两包数据
***********************************************
3.02.15 **3.02.15  2023.08.26 -0908
1. 修改了底层调用bandif的bug ，由调用bandInfo 改为调用MTSbandInfo
   该bug影响au915和us902两个标准
   //uplinkChan, err := b.bandInfo.GetUplinkChannelIndex(uplinkFrequency, true)
   uplinkChan, err := b.MTSbandInfo.GetUplinkChannelIndex(uplinkFrequency, true)
2. 修改对Upchannel和downChannel的默认值。 如果配置参数中为空，则设置为默认的频点配置
3. 修复了mtdtuIP在ClassA模式下的bug。ClassA模式下，收到mtdtuIP的上行数据后，100ms检查是否有下行数据，有的话下发
4. mapdel , map2pg 都可以通过 euiList的方式，实现针对指定的eui进行同步 。
   euiList为 空 时， map2pg 针对所有设备。 mapdel则执行whereInfo的where语句实现设备筛选
   https://mensikeji.yuque.com/ihnm5p/duukgm/xhh37tkxmab7hmeg#A3Qbd
5. 修改了安装方式
***********************************************
3.02.16 **  2023.09.11 -0912
1. 修复了，多网关接收时，位置偏差问题
2. 修复了，节点设备通过port 0接口发送mac指令解析的bug
***********************************************
3.02.17 **  2023.09.15 - 2023.10.24**
1. 修改了安装包的默认参数
3.优化了从redis到 pgsql的数据同步，当有数据修改的时候才同步
4.将非lorawan的数据分发给ParsePrivateDataUP 处理，目前只是做数据打印


***********************************************
3.02.18 **  2023.11.01 - 2023.**
1. 修改了网关位置信息更新的bug
2. 增加了租户修改范围保护，如果要全部修改，将whereInfo 置为 "*"
3. 生成网关和设备，不再回复全量信息，只回复批次和生成时间
4. 将初始化参数更新到tk{netEui}_bk库中
5. 升级通过pgsql实现mqtt消息的功能
6. 修改设备租户保护，对空euilist表示没有需要修改的设备
7. 升级了 logrus 到1.9.0
8. 修改mqtt的receive 中的callback为goroutine
***********************************************
3.02.19 **  2023.12.14 - 2023.**
1. 对wxzn和wxzncn03 这两个租户做了特殊处理，转发了gwstat到AS
    topic = /v32/{tenant}/as/up/gwstat/{gweui}
    topic 示例= /v32/wxzn/as/up/gwstat/5a53012a00000513
    msg 示例,其中 moteeui为网关的eui：
   {
   "version": "3.0",
   "type": "gwstat",
   "moteeui": "5a53012a00000513",
   "token": 127,
   "stat": {
   "time": "2023-12-08 11:16:58 GMT",
   "lati": 0,
   "long": 0,
   "alti": 0,
   "rxnb": 1,
   "rxok": 0,
   "rxfw": 0,
   "ackr": 200,
   "dwnb": 0,
   "txnb": 0,
   "temp": 0
   }
   }
2. 支持 应用层GPS数据提取
***********************************************
3.02.20 **  2024.01.23 
1. 生成devEui时，最后 4位为10进制递增
2. 兼容LoRaWAN1.0.4的帧号逻辑
***********************************************
3.02.21 **  2024.02.04 
1. 增加生产用的dev的信息库
***********************************************
3.02.23 **  2024.02.04 
1. 修改了空payload上行导致崩溃的bug
2. 修改了time request的bug
***********************************************
3.02.25 **  2024.03.17
1. 增加了生成sig设备的设计，配置好default参数后，可以实现可预期的三元组
2. 增加了数据上行和入网对无档案信息的sig节点的自动识别
3. 以上功能需要配置defaut 参数中启用sig的字段，并配置为true。一个thinkOne只能支持一个sig的默认配置
4. 修改pfFac的字段，将 testStatus、used修改为notnull和字符串类型。
5. 增加了 pfFac增加了 txCurrent rxCurrent sleepCurrent 三个字段
6. 已有的thinkOne升级需要将pfFac字段进行修改，大部分设备不使用pfFac，将原有的pfFac数据表删除，重新启动thinkOne即可解决
   对已经在使用的thinkOne的pfFac功能，需要手动修改pfFac的字段变化。
7. 执行 gwm -pg sql -query "DROP TABLE mt_sdev_pf_facs" -pswd 'tkpg!0902' -db tk240317_bk 命令，可以使删除Fac表，注意表名和密码需要正确填写
***********************************************
3.02.26 **  2024.04.04
1. 启动时 检查 redis的链接状态，pgsql的链接状态，downEnable的状态，broker的链接状态
2. 解决同步redis到pgsql的bug
3. 增加默认配置时，如果参数中没有改命名，需要从数据库中读取一次进行更新
4. 修改 设备的属性参数时（如 disable, tenant 等操作） whereInfo 应该用 "redis://" "pgsql://"开始，用于区分是从pgsql中进行筛选还是从redis中筛选
5. 筛选redis数据方法: whereInfo="redis://tenant=mskj,standard!AS923" 。只有等或者非两种判断
EuiList=["*"] 为选择redis中的所有数据项
6. 操作方法见 https://mensikeji.yuque.com/ihnm5p/duukgm/gguns8qz6gdd2u9e?singleDoc# 《CASE-thinkOne3.0【内部】运维手册》
