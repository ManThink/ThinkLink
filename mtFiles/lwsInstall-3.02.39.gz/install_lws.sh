#!/bin/sh

os=`uname`
echo "system is "$os
arch=`uname -m`
echo "arch is "$arch
binPath=./bin/
if [ "$os" != "Linux" ]; then
   echo "don't support the sytem and break the install"
   exit 0
fi
if [ $# -ne 2 ]; then
  echo "the format should be ./install_lws.sh -f conf.json"
  exit 0
elif [ "$1" != "-f"  ]; then
  echo "the format should be ./install_lws.sh -f conf.json"
  exit 0
fi
confJson=$2
mkdir -p /usr/local/mt/lws/lws-thinkOne/config
mkdir -p /usr/local/mt/lws/lws-nsbrg/config
#mkdir -p /usr/local/mt/lws/lws-cli/config
mkdir -p /usr/local/mt/lws/lws-asbrg/config
mkdir -p /usr/local/mt/lws/lws-dms/config
systemctl stop lws-thinkOne
systemctl stop lws-nsbrg
cp ./service/lws-thinkOne.service  /lib/systemd/system/
cp ./service/lws-nsbrg.service /lib/systemd/system/
if [ "$arch" = "aarch64" ]; then
  binPath=./bin/arm64/
elif [ "$arch" = "x86_64" ]; then
  binPath=./bin/x64/
  systemctl stop lws-dms
  cp ./service/lws-dms.service /lib/systemd/system/
else
  echo "don't support the arch and break the install"
  exit 0
fi
cp ${binPath}lws-thinkOne /usr/local/mt/lws/lws-thinkOne/
cp ${binPath}lws-nsbrg /usr/local/mt/lws/lws-nsbrg/
#cp ${binPath}lws-cli /usr/local/mt/lws/lws-cli/
cp ${binPath}lws-asbrg /usr/local/mt/lws/lws-asbrg/
cp ${binPath}lws-dms /usr/local/mt/lws/lws-dms/
cp ${binPath}gwm ./gwm
cp ${binPath}gwm /bin/

if test -f /usr/local/mt/lws/lws-thinkOne/config/thinkOne_conf.json; then
echo "thinkOne config file exist now!"
else
cp  ./config/thinkOne/*  /usr/local/mt/lws/lws-thinkOne/config/
fi
if test -f /usr/local/mt/lws/lws-nsbrg/config/nsbrg_conf.json; then
echo "nsbrg config file exist now!"
else
cp ./config/nsbrg/* /usr/local/mt/lws/lws-nsbrg/config/
fi
#if test -f /usr/local/mt/lws/lws-cli/config/cli_conf.json; then
#echo "cli config file exist now!"
#else
#cp ./config/cli/* /usr/local/mt/lws/lws-cli/config/
#fi
if test -f /usr/local/mt/lws/lws-asbrg/config/asbrg_conf.json; then
echo "asbrg config file exist now!"
else
cp ./config/asbrg/* /usr/local/mt/lws/lws-asbrg/config/
fi
if test -f /usr/local/mt/lws/lws-dms/config/dms_conf.json; then
echo "dms config file exist now!"
else
cp ./config/dms/* /usr/local/mt/lws/lws-dms/config/
fi
echo "start to config the parameters .................."
# paraConf /usr/local/mt/lws/lws-thinkOne/config/thinkOne_conf.json ns-broker ns:broker


#paraConf() {
#   read -p "--please input ${2} :" inputP
#   if [ "${inputP}" = "" ]; then
#     echo "default "${2}
#   else
#     echo "rewrite "${2}" with "${inputP}
#     ./gwm -txt write -fileType jsonFile -f ${1} -dataType string -dataName ${3} -dataVal ${inputP}
#   fi
#}
paraConf() {
    confPara=$(./gwm -txt read -fileType jsonFile -f ${confJson} -dataName ${2})
    echo "rewrite "${2}" with "${confPara}
    ./gwm -txt write -fileType jsonFile -f ${1} -dataType string -dataName ${2} -dataVal ${confPara}
}
tkConfFile="/usr/local/mt/lws/lws-thinkOne/config/thinkOne_conf.json"
nsConfFile="/usr/local/mt/lws/lws-nsbrg/config/nsbrg_conf.json"
asConfFile="/usr/local/mt/lws/lws-asbrg/config/asbrg_conf.json"
dmsConfFile="/usr/local/mt/lws/lws-nsbrg/config/dms_conf.json"
paraConf ${tkConfFile}  netEui
paraConf ${tkConfFile}  ns:broker
paraConf ${tkConfFile}  ns:username
paraConf ${tkConfFile}  ns:password
paraConf ${tkConfFile}  as:broker
paraConf ${tkConfFile}  as:username
paraConf ${tkConfFile}  as:password
paraConf ${tkConfFile}  dms:broker
paraConf ${tkConfFile}  dms:username
paraConf ${tkConfFile}  dms:password

paraConf ${tkConfFile}  postgre:server
paraConf ${tkConfFile}  postgre:user
paraConf ${tkConfFile}  postgre:pswd
paraConf ${tkConfFile}  postgre:dbName
paraConf ${tkConfFile}  postgrebk:server
paraConf ${tkConfFile}  postgrebk:user
paraConf ${tkConfFile}  postgrebk:pswd
paraConf ${tkConfFile}  postgrebk:dbName

redispswd=$(./gwm -txt read -fileType jsonFile -f ${confJson} -dataName redispswd)
./gwm -txt write -fileType jsonFile -f ${tkConfFile} -dataType string -dataName redisDev:pswd -dataVal ${redispswd}
./gwm -txt write -fileType jsonFile -f ${tkConfFile} -dataType string -dataName redisPay:pswd -dataVal ${redispswd}
./gwm -txt write -fileType jsonFile -f ${tkConfFile} -dataType string -dataName redisGw:pswd -dataVal ${redispswd}
./gwm -txt write -fileType jsonFile -f ${tkConfFile} -dataType string -dataName redisDnData:pswd -dataVal ${redispswd}
./gwm -txt write -fileType jsonFile -f ${tkConfFile} -dataType string -dataName redisTemp:pswd -dataVal ${redispswd}

./gwm -txt write -fileType jsonFile -f ${nsConfFile} -dataType string -dataName redisGw:pswd -dataVal ${redispswd}
./gwm -txt write -fileType jsonFile -f ${dmsConfFile} -dataType string -dataName redis:pswd -dataVal ${redispswd}

netEui=$(./gwm -txt read -fileType jsonFile -f ${tkConfFile} -dataName netEui)
nsbroker=$(./gwm -txt read -fileType jsonFile -f ${tkConfFile} -dataName ns:broker)
nsuname=$(./gwm -txt read -fileType jsonFile -f ${tkConfFile} -dataName ns:username)
nspswd=$(./gwm -txt read -fileType jsonFile -f ${tkConfFile} -dataName ns:password)
echo "netEui is :"${netEui}
#dbNameBK=$(./gwm -txt read -fileType jsonFile -f ${tkConfFile} -dataName postgrebk:dbName)
#if [ "${dbNameBK}" = "" ]; then
#    ./gwm -txt write -fileType jsonFile -f ${tkConfFile} -dataType string -dataName postgrebk:dbName -dataVal tk${netEui}_bk
#fi
./gwm -txt write -fileType jsonFile -f ${nsConfFile} -dataType string -dataName nsBroker -dataVal ${nsbroker}
./gwm -txt write -fileType jsonFile -f ${nsConfFile} -dataType string -dataName nsUserName -dataVal  ${nsuname}
./gwm -txt write -fileType jsonFile -f ${nsConfFile} -dataType string -dataName nsPassword -dataVal  ${nspswd}
./gwm -txt write -fileType jsonFile -f ${nsConfFile} -dataType string -dataName nmsBroker -dataVal ${nsbroker}
./gwm -txt write -fileType jsonFile -f ${nsConfFile} -dataType string -dataName nmsUserName -dataVal  ${nsuname}
./gwm -txt write -fileType jsonFile -f ${nsConfFile} -dataType string -dataName nmsPassword -dataVal  ${nspswd}
./gwm -txt write -fileType jsonFile -f ${nsConfFile} -dataType string -dataName brgBroker -dataVal ${nsbroker}
./gwm -txt write -fileType jsonFile -f ${nsConfFile} -dataType string -dataName brgUserName -dataVal  ${nsuname}
./gwm -txt write -fileType jsonFile -f ${nsConfFile} -dataType string -dataName brgPassword -dataVal  ${nspswd}



./gwm -txt write -fileType jsonFile -f ${dmsConfFile} -dataType string -dataName dms:broker -dataVal ${nsbroker}
./gwm -txt write -fileType jsonFile -f ${dmsConfFile} -dataType string -dataName dms:username -dataVal  ${nsuname}
./gwm -txt write -fileType jsonFile -f ${dmsConfFile} -dataType string -dataName dms:password -dataVal  ${nspswd}

systemctl enable lws-thinkOne
systemctl daemon-reload
systemctl restart lws-thinkOne
#systemctl status lws-thinkOne

systemctl enable lws-nsbrg
systemctl daemon-reload
systemctl restart lws-nsbrg
#systemctl status lws-nsbrg
if [ "$arch" = "aarch64" ]; then
  echo "arch is aarch64"
elif [ "$arch" = "x86_64" ]; then
systemctl enable lws-dms
systemctl daemon-reload
systemctl restart lws-dms
#systemctl status lws-dms
else
  echo "don't support the arch and break the install"
  exit 0
fi
echo "install complete!!!!"

