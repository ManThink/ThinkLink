class MT_IdxPara {
    constructor(idx = 0, invert = false) {
        this.Idx = idx;
        this.Invert = invert;
    }
}

module.exports = MT_IdxPara;
